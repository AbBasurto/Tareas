package Actividad3;

	public class Main {
	    public static void main(String[] args) {
	        Deck deck = new Deck();

	        deck.shuffle();

	        System.out.println("Carta al inicio del Deck:");
	        deck.head();

	        System.out.println("\nCarta retirada al azar:");
	        deck.pick();

	        System.out.println("\nMano de cinco cartas:");
	        deck.hand();
	    }
	}