package Actividad3;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class Deck {
	 private List<Card> cards;

	    public Deck() {
	        cards = new ArrayList<>();
	        initializeDeck();
	    }

	    // Inicializa las 52 cartas del mazo de poker
	    private void initializeDeck() {
	        String[] palos = {"Tréboles", "Corazones", "Picas", "Diamantes"};
	        String[] colores = {"Negro", "Rojo"};
	        String[] valores = {"2", "3", "4", "5", "6", "7", "8", "9", "10", "A", "J", "Q", "K"};

	        for (String palo : palos) {
	            for (String color : colores) {
	                for (String valor : valores) {
	                    cards.add(new Card(palo, color, valor));
	                }
	            }
	        }
	    }

	    // Mezcla el mazo de cartas
	    public void shuffle() {
	        Collections.shuffle(cards);
	        System.out.println("Se mezcló el Deck");
	    }

	    // Muestra y quita la primera carta del mazo
	    public void head() {
	        if (!cards.isEmpty()) {
	            Card card = cards.remove(0);
	            System.out.println(card.toString());
	            System.out.println("Quedan " + cards.size() + " cartas en el Deck");
	        } else {
	            System.out.println("No quedan cartas en el Deck");
	        }
	    }

	    // Selecciona y quita una carta al azar del mazo
	    public void pick() {
	        if (!cards.isEmpty()) {
	            Random random = new Random();
	            int randomIndex = random.nextInt(cards.size());
	            Card card = cards.remove(randomIndex);
	            System.out.println(card.toString());
	            System.out.println("Quedan " + cards.size() + " cartas en el Deck");
	        } else {
	            System.out.println("No quedan cartas en el Deck");
	        }
	    }

	    // Obtiene y quita una mano de cinco cartas del mazo
	    public void hand() {
	        if (cards.size() >= 5) {
	            for (int i = 0; i < 5; i++) {
	                Card card = cards.remove(0);
	                System.out.println(card.toString());
	            }
	            System.out.println("Quedan " + cards.size() + " cartas en el Deck");
	        } else {
	            System.out.println("No hay suficientes cartas en el Deck para repartir una mano de cinco cartas.");
	        }
	    }
	}

